package com.luma.focus.ui.screens

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.luma.focus.ai.AiRepository
import com.luma.focus.data.LumaStore
import com.luma.focus.ui.theme.*
import kotlinx.coroutines.launch
import java.util.Calendar

@Composable
fun AiScreen(accent: Color) {
    val scope = rememberCoroutineScope()
    val context = LocalContext.current
    var result by remember { mutableStateOf("") }
    var chatAnswer by remember { mutableStateOf("") }
    var question by remember { mutableStateOf("") }
    var loading by remember { mutableStateOf(false) }
    var imageUri by remember { mutableStateOf<android.net.Uri?>(null) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { imageUri = it }

    val today = LumaStore.today()
    val sessions = LumaStore.getFocusSessions()
    val todaySessions = sessions.filter { it.date == today }
    val todayFocus = todaySessions.sumOf { it.activeSeconds } / 60
    val completed = todaySessions.count { it.plannedSeconds > 0 && it.activeSeconds >= it.plannedSeconds }
    val pauses = todaySessions.sumOf { it.pauseCount }
    val tasks = LumaStore.tasksForDate(today)
    val habits = LumaStore.habitsForDate(today)
    val journal = LumaStore.journalForDate(today)
    val weekFocus = run {
        val c = Calendar.getInstance()
        val f = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US)
        val days = mutableSetOf<String>()
        repeat(7) {
            days += f.format(c.time)
            c.add(Calendar.DAY_OF_YEAR, -1)
        }
        sessions.filter { it.date in days }.sumOf { it.activeSeconds } / 60
    }
    val monthFocus = sessions.filter { it.date >= today.substring(0, 8) + "01" }.sumOf { it.activeSeconds } / 60
    val historySummary = sessions.takeLast(120).joinToString("; ") { s ->
        "${s.date}:${s.activeSeconds / 60}m/${s.plannedSeconds / 60}m/${s.mode}/${s.sound}/${s.wallpaper}"
    }

    fun contextPrompt(): String = buildString {
        append("You are Luma, a practical ADHD-friendly productivity analyst. Use only the supplied data; do not invent facts. ")
        append("Do not diagnose medical conditions. Label correlations as correlations, not causation. ")
        append("Today=$today. TodayFocus=${todayFocus}min. CompletedFocusSessions=$completed. Pauses=$pauses. ")
        append("WeekFocus=${weekFocus}min. MonthFocus=${monthFocus}min. RecentSessions=$historySummary. ")
        append("Tasks=${tasks.joinToString { it.title + if (it.done) "[done]" else "[open]" }}. ")
        append("Habits=${habits.joinToString { it.first.title + "=" + it.second + "%" }}. ")
        append("Journal=${journal.flatMap { it.sections }.joinToString { it.label + ":" + it.content }}. ")
    }

    Column(
        Modifier.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState())
    ) {
        Text("Luma AI", fontSize = 28.sp, fontWeight = FontWeight.ExtraBold, color = accent)
        Text("Your personal productivity analyst", color = LumaTextSecondary)
        Spacer(Modifier.height(14.dp))

        Card {
            Column(Modifier.padding(16.dp)) {
                Text("Today at a glance", fontWeight = FontWeight.Bold)
                Text("Focus: $todayFocus min  •  Sessions: ${todaySessions.size}  •  Pauses: $pauses", color = LumaTextSecondary)
                Text("Tasks: ${tasks.count { it.done }}/${tasks.size}  •  Habits: ${if (habits.isEmpty()) 0 else habits.map { it.second }.average().toInt()}%", color = LumaTextSecondary)
                Text("7-day focus: $weekFocus min  •  This month: $monthFocus min", color = LumaTextSecondary)
                Spacer(Modifier.height(10.dp))
                Button(enabled = !loading, onClick = {
                    loading = true
                    scope.launch {
                        result = AiRepository.analyze(LumaStore.getApiKey(), LumaStore.getAiModel(), contextPrompt() +
                            "Give: wins, unfinished work, focus pattern, habit pattern, journal insight, weaknesses, and a tiny plan for tomorrow.")
                            .getOrElse { it.message ?: "AI failed" }
                        loading = false
                    }
                }, colors = ButtonDefaults.buttonColors(containerColor = accent)) {
                    Text(if (loading) "Thinking…" else "Analyze my day")
                }
            }
        }

        Spacer(Modifier.height(14.dp))
        OutlinedTextField(question, { question = it }, label = { Text("Ask about my history") }, modifier = Modifier.fillMaxWidth(), minLines = 2)
        Spacer(Modifier.height(8.dp))
        Button(enabled = !loading && question.isNotBlank(), onClick = {
            loading = true
            scope.launch {
                chatAnswer = AiRepository.analyze(LumaStore.getApiKey(), LumaStore.getAiModel(), contextPrompt() +
                    "Answer this user question precisely and briefly: $question")
                    .getOrElse { it.message ?: "AI failed" }
                loading = false
            }
        }, colors = ButtonDefaults.buttonColors(containerColor = accent)) { Text("Ask Luma") }
        if (chatAnswer.isNotBlank()) Card(Modifier.padding(top = 10.dp)) { Text(chatAnswer, Modifier.padding(16.dp), color = LumaTextPrimary) }

        Spacer(Modifier.height(14.dp))
        Button(onClick = { picker.launch("image/*") }, colors = ButtonDefaults.buttonColors(containerColor = accent)) {
            Text(if (imageUri == null) "Choose image for AI" else "Image selected")
        }
        if (imageUri != null) {
            Spacer(Modifier.height(6.dp))
            Button(enabled = !loading, onClick = {
                loading = true
                scope.launch {
                    result = AiRepository.analyzeImage(context, LumaStore.getApiKey(), LumaStore.getAiModel(), imageUri!!)
                        .getOrElse { it.message ?: "AI failed" }
                    loading = false
                }
            }, colors = ButtonDefaults.buttonColors(containerColor = accent)) { Text("Analyze image") }
        }

        if (result.isNotBlank()) {
            Spacer(Modifier.height(12.dp))
            Card { Text(result, Modifier.padding(16.dp), color = LumaTextPrimary) }
        }

        Spacer(Modifier.height(12.dp))
        Text("AI uses your Luma history only when you ask it to analyze or answer a question. Configure your provider in Settings. Never put a production API key directly in a public APK.", color = LumaTextSecondary, fontSize = 11.sp)
    }
}
