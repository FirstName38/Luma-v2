package com.luma.focus.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.CameraSelector
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import com.luma.focus.data.FocusSession
import com.luma.focus.data.LumaStore
import com.luma.focus.ui.theme.*
import kotlinx.coroutines.delay
import java.util.UUID

private fun clock(seconds: Long): String = String.format("%02d:%02d", seconds / 60, seconds % 60)

@Composable
fun FocusRoomScreen(accent: Color) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    var cameraOn by remember { mutableStateOf(false) }
    var muted by remember { mutableStateOf(true) }
    var hasCameraPermission by remember { mutableStateOf(ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) }
    var taskLabel by remember { mutableStateOf("Studying") }
    var mode by remember { mutableStateOf("Standard") }
    var duration by remember { mutableStateOf(25) }
    var running by remember { mutableStateOf(false) }
    var elapsed by remember { mutableStateOf(0L) }
    var startedAt by remember { mutableStateOf(0L) }
    var pauseStartedAt by remember { mutableStateOf<Long?>(null) }
    var pausedSeconds by remember { mutableStateOf(0L) }
    var pauseCount by remember { mutableStateOf(0) }

    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        hasCameraPermission = granted
        if (granted) cameraOn = true
    }

    LaunchedEffect(running) {
        while (running) {
            delay(1000)
            elapsed++
            if (elapsed >= duration * 60L) {
                val end = System.currentTimeMillis()
                val finalPaused = pausedSeconds + (pauseStartedAt?.let { (end - it) / 1000L } ?: 0L)
                LumaStore.addFocusSession(FocusSession(UUID.randomUUID().toString(), LumaStore.today(), duration, "Room: $taskLabel", LumaStore.getSelectedWallpaper(), LumaStore.getSelectedSound(), mode, "Focus Room", startedAt, end, duration * 60L, finalPaused, pauseCount, emptyList(), duration * 60L))
                running = false
                startedAt = 0L
                elapsed = 0L
                pauseStartedAt = null
                pausedSeconds = 0L
                pauseCount = 0
            }
        }
    }

    fun stopRoom() {
        if (startedAt > 0L && elapsed > 0L) {
            val end = System.currentTimeMillis()
            val finalPaused = pausedSeconds + (pauseStartedAt?.let { (end - it) / 1000L } ?: 0L)
            LumaStore.addFocusSession(FocusSession(UUID.randomUUID().toString(), LumaStore.today(), (elapsed / 60L).toInt().coerceAtLeast(1), "Room: $taskLabel", LumaStore.getSelectedWallpaper(), LumaStore.getSelectedSound(), mode, "Focus Room", startedAt, end, elapsed, finalPaused, pauseCount, emptyList(), duration * 60L))
        }
        running = false
        elapsed = 0
        startedAt = 0
        pauseStartedAt = null
        pausedSeconds = 0L
        pauseCount = 0
    }

    Column(Modifier.fillMaxSize().background(wallpaperByName(LumaStore.getSelectedWallpaper()).brush).padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text("Focus Room", fontSize = 27.sp, fontWeight = FontWeight.ExtraBold, color = accent)
        Text("Private accountability room • nothing is streamed by Luma", color = LumaTextSecondary, fontSize = 12.sp)
        Spacer(Modifier.height(12.dp))

        Box(Modifier.fillMaxWidth().height(230.dp).background(Color.Black), contentAlignment = Alignment.Center) {
            if (cameraOn && hasCameraPermission) {
                AndroidView(modifier = Modifier.fillMaxSize(), factory = { ctx ->
                    val previewView = PreviewView(ctx)
                    val future = ProcessCameraProvider.getInstance(ctx)
                    future.addListener({
                        val provider = future.get()
                        val preview = Preview.Builder().build().also { it.setSurfaceProvider(previewView.surfaceProvider) }
                        try {
                            provider.unbindAll()
                            provider.bindToLifecycle(lifecycleOwner, CameraSelector.DEFAULT_FRONT_CAMERA, preview)
                        } catch (_: Exception) { }
                    }, ContextCompat.getMainExecutor(ctx))
                    previewView
                })
            } else Text("Camera off", color = LumaTextSecondary)
        }

        Spacer(Modifier.height(12.dp))
        LazyRow(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            items(listOf("Standard", "ADHD", "Custom")) { m -> FilterChip(selected = mode == m, onClick = { if (!running) { mode = m; duration = if (m == "ADHD") 10 else duration } }, label = { Text(m) }) }
        }
        OutlinedTextField(taskLabel, { if (!running) taskLabel = it }, label = { Text("What are you working on?") }, modifier = Modifier.fillMaxWidth())
        if (!running) {
            Text("Duration: $duration min", color = LumaTextSecondary, modifier = Modifier.padding(top = 6.dp))
            Slider(value = duration.toFloat(), onValueChange = { duration = it.toInt().coerceIn(5, 120) }, valueRange = 5f..120f)
        }
        Text(clock((duration * 60L - elapsed).coerceAtLeast(0)), fontSize = 52.sp, fontWeight = FontWeight.ExtraBold, color = accent)

        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            FilledIconButton(onClick = {
                if (!cameraOn) { if (hasCameraPermission) cameraOn = true else permissionLauncher.launch(Manifest.permission.CAMERA) } else cameraOn = false
            }) { Text(if (cameraOn) "Cam" else "Off") }
            FilledIconButton(onClick = { muted = !muted }) { Text(if (muted) "Mute" else "Mic") }
            Button(onClick = {
                if (running) {
                    running = false
                    pauseStartedAt = System.currentTimeMillis()
                    pauseCount++
                } else {
                    val now = System.currentTimeMillis()
                    pauseStartedAt?.let { pausedSeconds += (now - it) / 1000L }
                    pauseStartedAt = null
                    if (startedAt == 0L) startedAt = now
                    running = true
                }
            }, colors = ButtonDefaults.buttonColors(containerColor = accent)) { Text(if (running) "Pause" else if (elapsed > 0) "Resume" else "Start") }
            OutlinedButton(onClick = { stopRoom() }) { Text("End") }
        }

        Spacer(Modifier.height(10.dp))
        Text("Room history is saved as Focus Room sessions in Calendar/AI analytics.", color = LumaTextSecondary, fontSize = 11.sp)
    }
}
