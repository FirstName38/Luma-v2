# Luma 2.0 — Focus & Productivity Companion

Luma is an Android productivity environment designed around focus sessions, ADHD-friendly workflows, personal history, and an optional AI coach.

## Included

- Focus timer: Standard, ADHD, Custom and Stopwatch modes
- Focus / short-break switching, pause/resume and finish
- Persistent focus-session history with duration, mode, sound, wallpaper and pause metrics
- Built-in looping ambience: Rain, LoFi, White Noise, Forest, Chime, Soft and Deep Focus
- Separate focus and break sounds
- Aesthetic focus wallpapers with saved session context
- Tasks with dates, priorities, labels, descriptions and reminders
- Calendar with day-based focus/task/habit/journal information
- Habits with daily percentage progress, streak-oriented history and reminders architecture
- Journal with learning/feeling/plan sections and image attachments
- Clock section with countdown timer, stopwatch and alarm
- App usage reporting through Android Usage Access
- Focus blocking through Android Accessibility Service
- Private Focus Room with camera preview, mute/camera controls, task, mode, duration, pause/resume and saved room-session history
- AI day analysis
- AI questions about the user's Luma history
- AI image analysis for study/work images
- AI weekly/monthly/history context and productivity pattern analysis
- Settings for AI configuration, focus defaults, sounds, wallpapers, app controls and permissions
- Android notification, exact-alarm, camera, accessibility and usage-access setup paths
- GitHub Actions workflow that builds a debug APK with Java 17 and Gradle 8.9

## Important limitation: AI

The project does not contain a shared Luma API key. The user must configure an AI provider key in Settings for network AI features to work.

For a real production/public app, do **not** ship a provider secret inside the APK. Use a backend/proxy that authenticates the user and keeps provider credentials server-side. Direct client-side API-key configuration is intended for personal testing.

## Important limitation: Focus Room

The included Focus Room is a **private single-device accountability room**. Camera/microphone controls and a structured room session are implemented, but there is no fake claim that other people are connected. Real multiplayer requires a backend/signalling service and WebRTC or an equivalent real-time transport.

## Build

GitHub Actions is configured to use:

- Java 17
- Android Gradle Plugin 8.7.3
- Kotlin 2.0.21
- Gradle 8.9
- compileSdk 34 / targetSdk 34

The repository workflow produces `app/build/outputs/apk/debug/app-debug.apk` as an Actions artifact.

## Android permissions

Some features cannot work until Android grants their required access:

- Notifications — reminders and session notifications
- Camera — Focus Room camera
- Accessibility Service — app blocking
- Usage Access — app usage analysis
- Exact alarms — scheduled alarms/reminders on supported Android versions

Luma should explain these permissions instead of assuming they are automatically granted.

## Product principle

Functionality first, then reliability, interaction quality, visual polish and release packaging. A successful Gradle build alone is not considered proof that every feature is manually verified.
